import abi from './Transaction.json'

export const contractABI = abi.abi;
export const contractAddress = '0x6493e195356Ae867d69761e35C10e7FC0310F0eD';